/*
Convert string into upper case.
*/

const str = "Cats";

console.log(str.toUpperCase("Cats")); // CATS
