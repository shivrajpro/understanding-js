/*
Convert string into lower case.
*/

const str = "Cats";

console.log(str.toLowerCase("Cats")); // cats
