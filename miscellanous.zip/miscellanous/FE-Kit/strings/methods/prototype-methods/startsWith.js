/*
Check if string starts with specified character(s).
*/

const str = "Cats are the best!";

console.log(str.startsWith("Cats")); //True
