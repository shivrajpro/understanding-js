/*
Return new string with specified number of copies of existing string.
*/

const str = "JavaScript ";

console.log(str.repeat(2)); // "JavaScript JavaScript"
console.log(str.repeat(0)); // ""
