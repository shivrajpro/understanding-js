/*
* This function returns the characters in a string beginning at “start” and 
* through the specified number of characters, “length”. “Length” is optional, and 
* if omitted, up to the end of the string is

* Syntax - str.substring(fromIndex, toIndex)

? Note: "toIndex" is not counted 

*/

const str = "JavaScript-is-amazing";

console.log(str.substring(2, 6)); // vaSc
