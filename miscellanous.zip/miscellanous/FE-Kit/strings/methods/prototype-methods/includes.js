/*
Check if string contains specified character(s).
*/

const str = "Cats are the best!";

console.log(str.includes("are")); //True
