/*
This function removes whitespace from both ends of a string.
*/

const str = " Cats are the best! ";

console.log(str.trim()); // "Cats are the best!"
