/*
Split string into array of substrings.
*/

const str = "JavaScript-is-amazing";

console.log(str.split()); // [ 'JavaScript-is-amazing' ]
console.log(str.split("-")); // [ 'JavaScript', 'is', 'amazing' ]
