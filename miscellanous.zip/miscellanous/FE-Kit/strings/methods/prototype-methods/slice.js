/*
 * Copy some part of string without modifying the original one.
 */

const str = "Cats are the best!";
const result = str.slice(3); // s are the best!

console.log(str); // "Cats are the best!"
