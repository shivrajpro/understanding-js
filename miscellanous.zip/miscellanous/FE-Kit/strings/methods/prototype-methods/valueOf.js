/*
Returns the primitive value of a String object.
*/

const stringObj = new String("foo");

console.log(stringObj); // String { "foo" }

console.log(stringObj.valueOf()); // "foo"
