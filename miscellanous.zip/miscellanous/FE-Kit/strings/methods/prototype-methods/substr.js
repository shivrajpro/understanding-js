/*
* This function returns the characters in a string beginning at “start” and 
* through the specified number of characters, “length”. “Length” is optional, and 
* if omitted, up to the end of the string is

* Syntax - str.substr(startIndex, length)

*/

const str = "JavaScript-is-amazing";

console.log(str.substr(1, 4)); // avaS
