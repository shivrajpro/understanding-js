
=> Import statement is used to import LIVE bindings exported by another module.

=> Imported modules are in strict mode whether you declare them as such or not.

=> The import statement cannot be used in embedded scripts unless such script has a type="module"

=> There is also a function-like dynamic import(), which does not require scripts of type="module".

=> Backward compatibility can be ensured using attribute nomodule on the script tag.


