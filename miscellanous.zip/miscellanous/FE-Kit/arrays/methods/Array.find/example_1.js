// Find the first prime number in an array

