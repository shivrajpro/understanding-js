/*
Reverses the array
*/

const num = [1, 2, 3, 4];

console.log(num.reverse());
