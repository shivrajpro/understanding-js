// Create Using Array()

Array(3).fill(4) // [4, 4, 4]