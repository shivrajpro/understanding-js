// Create an object with empty array

console.log([].fill.call({ length: 4 }, "nuts"));
// { '0': 'nuts', '1': 'nuts', '2': 'nuts', '3': 'nuts', length: 4 }