const fruits = ["apple", "banana", "orange"];

// Example 1
const juices = fruits.map((fruit, index) => {
  return (fruit + " juice in cup " + index)
})

// console.log(juices);

// Example 2

