/*
This method will return true if the array contains a certain element, 
and false if not.
*/

// Example 1
const fruits = ["apple", "banana", "orange"];

console.log(fruits.includes("apple"));
