// Once upon a time, there was a king who loved palindromes. He had a secret chamber 
// in his castle where he kept all the palindromic words he had ever encountered. 
// One day, he was presented with a string A of length N and asked his royal advisor 
// to find the length of the longest palindrome that could be made from these letters. 
// The royal advisor was puzzled, as he did not know how to solve this problem. 
// Can you help him and solve the problem? 