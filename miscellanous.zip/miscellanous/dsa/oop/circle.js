// https://www.scaler.com/academy/mentee-dashboard/class/75312/assignment/problems/27007?navref=cl_tt_lst_sl
class Circle {
  // Define constructor here
  r = 0;
  PI = 3.14;
  constructor(r) {
    this.r = r;
  }
  perimeter() {
    // Complete the function
  }

  area() {
    // Complete the function
  }
}

a = new Circle(3); // Radius = 3
a.perimeter(); // 18.84
a.area(); // 28.26
