// Farmer Pickles is obsessed with three factor numbers. 
// Three Factor Numbers are integers that have atleast 3 factors. 
// He gave Bob an array A of size N and asked him Q queries, where in each query 
// he gives him a range from L to R and asks him to find the count of three factor 
// numbers in subarray ALL], A[L+1], ... A[R]. Bob is busy with construction work, 
// so he asks you to find the answer of all Famer Pickles queries. 
